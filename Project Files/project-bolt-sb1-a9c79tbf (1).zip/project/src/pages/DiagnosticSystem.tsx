import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Upload, 
  Microscope, 
  Brain, 
  FileText, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Download,
  Share2,
  BarChart3
} from 'lucide-react';

const DiagnosticSystem: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisComplete, setAnalysisComplete] = useState(false);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setAnalysisComplete(false);
    }
  };

  const handleAnalysis = () => {
    if (selectedFile) {
      setIsAnalyzing(true);
      // Simulate analysis
      setTimeout(() => {
        setIsAnalyzing(false);
        setAnalysisComplete(true);
      }, 3000);
    }
  };

  const analysisResults = {
    cellCounts: {
      neutrophils: 65,
      lymphocytes: 25,
      monocytes: 7,
      eosinophils: 3
    },
    totalCells: 1247,
    confidence: 99.2,
    processingTime: '47ms'
  };

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Automated Diagnostic System
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Professional-grade blood cell classification for clinical environments. 
            Upload blood smear images for instant AI-powered analysis.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Upload Section */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
              <h2 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
                <Upload className="h-6 w-6 mr-3 text-blue-600" />
                Upload Blood Smear Image
              </h2>

              <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-blue-400 transition-colors duration-300">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <Microscope className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-lg font-medium text-gray-700 mb-2">
                    Click to upload or drag and drop
                  </p>
                  <p className="text-sm text-gray-500">
                    Supports JPG, PNG, TIFF formats (Max 10MB)
                  </p>
                </label>
              </div>

              {selectedFile && (
                <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-blue-900">{selectedFile.name}</p>
                      <p className="text-sm text-blue-600">
                        {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                    <CheckCircle className="h-6 w-6 text-green-500" />
                  </div>
                </div>
              )}

              <button
                onClick={handleAnalysis}
                disabled={!selectedFile || isAnalyzing}
                className="w-full mt-6 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold py-4 px-6 rounded-xl hover:from-blue-700 hover:to-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center"
              >
                {isAnalyzing ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Brain className="h-5 w-5 mr-3" />
                    Start Analysis
                  </>
                )}
              </button>
            </div>

            {/* System Features */}
            <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">System Features</h3>
              <div className="space-y-4">
                {[
                  { icon: Brain, title: 'Transfer Learning', desc: 'Pre-trained CNN models' },
                  { icon: Clock, title: 'Real-time Processing', desc: 'Results in under 50ms' },
                  { icon: FileText, title: 'Detailed Reports', desc: 'Comprehensive analysis' },
                  { icon: BarChart3, title: 'Statistical Analysis', desc: 'Cell count distributions' }
                ].map((feature, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <div className="bg-blue-100 p-2 rounded-lg">
                      <feature.icon className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{feature.title}</p>
                      <p className="text-sm text-gray-600">{feature.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Results Section */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="space-y-8"
          >
            {analysisComplete ? (
              <>
                {/* Analysis Results */}
                <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-2xl font-semibold text-gray-900">Analysis Results</h3>
                    <div className="flex items-center text-green-600">
                      <CheckCircle className="h-5 w-5 mr-2" />
                      <span className="font-medium">Complete</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-8">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <p className="text-sm text-blue-600 font-medium">Total Cells</p>
                      <p className="text-2xl font-bold text-blue-900">{analysisResults.totalCells}</p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <p className="text-sm text-green-600 font-medium">Confidence</p>
                      <p className="text-2xl font-bold text-green-900">{analysisResults.confidence}%</p>
                    </div>
                  </div>

                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Cell Distribution</h4>
                  <div className="space-y-4">
                    {Object.entries(analysisResults.cellCounts).map(([cellType, percentage]) => (
                      <div key={cellType} className="space-y-2">
                        <div className="flex justify-between">
                          <span className="capitalize font-medium text-gray-700">{cellType}</span>
                          <span className="font-semibold text-gray-900">{percentage}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-blue-500 to-indigo-500 h-2 rounded-full transition-all duration-1000"
                            style={{ width: `${percentage}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-8 flex space-x-4">
                    <button className="flex-1 bg-blue-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center">
                      <Download className="h-5 w-5 mr-2" />
                      Download Report
                    </button>
                    <button className="flex-1 border border-gray-300 text-gray-700 font-semibold py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center">
                      <Share2 className="h-5 w-5 mr-2" />
                      Share Results
                    </button>
                  </div>
                </div>

                {/* Processing Details */}
                <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
                  <h3 className="text-xl font-semibold text-gray-900 mb-6">Processing Details</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Processing Time</span>
                      <span className="font-semibold text-gray-900">{analysisResults.processingTime}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Model Version</span>
                      <span className="font-semibold text-gray-900">HematoVision v2.1</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Algorithm</span>
                      <span className="font-semibold text-gray-900">Transfer Learning CNN</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Quality Score</span>
                      <span className="font-semibold text-green-600">Excellent</span>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 text-center">
                <Microscope className="h-24 w-24 text-gray-300 mx-auto mb-6" />
                <h3 className="text-xl font-semibold text-gray-900 mb-4">
                  Ready for Analysis
                </h3>
                <p className="text-gray-600">
                  Upload a blood smear image to begin automated cell classification and analysis.
                </p>
              </div>
            )}
          </motion.div>
        </div>

        {/* Clinical Integration Info */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-16 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-8 border border-blue-100"
        >
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Clinical Integration Benefits
            </h3>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Seamlessly integrate HematoVision into your existing laboratory workflow
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: Clock,
                title: 'Reduced Turnaround Time',
                description: 'Decrease analysis time from hours to minutes'
              },
              {
                icon: CheckCircle,
                title: 'Improved Accuracy',
                description: '99.2% classification accuracy with consistent results'
              },
              {
                icon: FileText,
                title: 'Standardized Reporting',
                description: 'Automated report generation with detailed analytics'
              }
            ].map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="bg-white w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <benefit.icon className="h-8 w-8 text-blue-600" />
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">{benefit.title}</h4>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default DiagnosticSystem;