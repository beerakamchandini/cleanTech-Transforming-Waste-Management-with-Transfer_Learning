import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Video, 
  Upload, 
  Users, 
  Globe, 
  Shield, 
  Clock,
  MessageSquare,
  FileText,
  Phone,
  Monitor,
  Wifi,
  Lock
} from 'lucide-react';

const TelemedicinePlatform: React.FC = () => {
  const [activeTab, setActiveTab] = useState('consultation');

  const consultationSteps = [
    {
      step: 1,
      title: 'Schedule Consultation',
      description: 'Book appointment with specialist',
      icon: Clock
    },
    {
      step: 2,
      title: 'Upload Blood Samples',
      description: 'Secure image upload to platform',
      icon: Upload
    },
    {
      step: 3,
      title: 'AI Analysis',
      description: 'Automated cell classification',
      icon: Monitor
    },
    {
      step: 4,
      title: 'Expert Review',
      description: 'Specialist consultation with results',
      icon: Video
    }
  ];

  const platformFeatures = [
    {
      icon: Shield,
      title: 'HIPAA Compliant',
      description: 'End-to-end encryption and secure data handling'
    },
    {
      icon: Globe,
      title: 'Global Access',
      description: 'Connect with specialists worldwide'
    },
    {
      icon: Wifi,
      title: 'Real-time Collaboration',
      description: 'Live consultation with instant results'
    },
    {
      icon: FileText,
      title: 'Digital Records',
      description: 'Comprehensive patient history tracking'
    }
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Telemedicine Platform
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Revolutionizing remote healthcare with AI-powered blood cell analysis. 
            Connect patients with specialists for accurate diagnostics from anywhere.
          </p>
        </motion.div>

        {/* Platform Demo */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="bg-white rounded-2xl shadow-2xl overflow-hidden mb-16"
        >
          <div className="bg-gradient-to-r from-green-600 to-emerald-600 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="bg-white/20 p-2 rounded-lg">
                  <Video className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white">Live Consultation</h3>
                  <p className="text-green-100">Dr. Sarah Johnson - Hematologist</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-red-400 rounded-full animate-pulse"></div>
                <span className="text-white font-medium">LIVE</span>
              </div>
            </div>
          </div>

          <div className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Video Call Interface */}
              <div className="space-y-6">
                <div className="bg-gray-900 rounded-xl p-6 aspect-video flex items-center justify-center">
                  <div className="text-center text-white">
                    <Video className="h-16 w-16 mx-auto mb-4 opacity-50" />
                    <p className="text-lg font-medium">Video Consultation Active</p>
                    <p className="text-gray-400">Secure encrypted connection</p>
                  </div>
                </div>

                <div className="flex justify-center space-x-4">
                  <button className="bg-green-500 hover:bg-green-600 text-white p-3 rounded-full transition-colors">
                    <Phone className="h-5 w-5" />
                  </button>
                  <button className="bg-blue-500 hover:bg-blue-600 text-white p-3 rounded-full transition-colors">
                    <Video className="h-5 w-5" />
                  </button>
                  <button className="bg-gray-500 hover:bg-gray-600 text-white p-3 rounded-full transition-colors">
                    <MessageSquare className="h-5 w-5" />
                  </button>
                </div>
              </div>

              {/* Analysis Results */}
              <div className="space-y-6">
                <div className="bg-gray-50 rounded-xl p-6">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">
                    Real-time Analysis Results
                  </h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Neutrophils</span>
                      <span className="font-semibold text-gray-900">68%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Lymphocytes</span>
                      <span className="font-semibold text-gray-900">22%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Monocytes</span>
                      <span className="font-semibold text-gray-900">7%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Eosinophils</span>
                      <span className="font-semibold text-gray-900">3%</span>
                    </div>
                  </div>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                  <div className="flex items-center space-x-3">
                    <div className="bg-green-500 p-2 rounded-full">
                      <Shield className="h-4 w-4 text-white" />
                    </div>
                    <div>
                      <p className="font-medium text-green-900">Analysis Complete</p>
                      <p className="text-sm text-green-700">Results ready for specialist review</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Consultation Process */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              How Remote Consultation Works
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Streamlined process for accurate remote blood cell analysis and specialist consultation
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {consultationSteps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="relative mb-6">
                  <div className="bg-gradient-to-r from-green-500 to-emerald-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <step.icon className="h-8 w-8 text-white" />
                  </div>
                  <div className="absolute -top-2 -right-2 bg-white border-2 border-green-500 w-8 h-8 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold text-green-600">{step.step}</span>
                  </div>
                  {index < consultationSteps.length - 1 && (
                    <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-gray-300 transform -translate-y-1/2"></div>
                  )}
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Platform Features */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Platform Features
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive telemedicine solution with advanced security and collaboration tools
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {platformFeatures.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300"
              >
                <div className="bg-gradient-to-r from-green-500 to-emerald-500 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                  <feature.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Benefits Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-8 border border-green-100"
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Transforming Remote Healthcare
              </h2>
              <div className="space-y-6">
                {[
                  {
                    title: 'Improved Access',
                    description: 'Connect patients in remote areas with specialist expertise'
                  },
                  {
                    title: 'Faster Diagnosis',
                    description: 'Reduce waiting times with instant AI-powered analysis'
                  },
                  {
                    title: 'Cost Effective',
                    description: 'Lower healthcare costs through efficient remote consultations'
                  },
                  {
                    title: 'Quality Care',
                    description: 'Maintain high standards with expert oversight and AI assistance'
                  }
                ].map((benefit, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="bg-green-500 w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">{benefit.title}</h3>
                      <p className="text-gray-600">{benefit.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-lg">
              <div className="text-center mb-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Global Impact Statistics
                </h3>
                <p className="text-gray-600">Real-world results from our telemedicine platform</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { number: '50,000+', label: 'Remote Consultations' },
                  { number: '95%', label: 'Patient Satisfaction' },
                  { number: '75%', label: 'Faster Diagnosis' },
                  { number: '40%', label: 'Cost Reduction' }
                ].map((stat, index) => (
                  <div key={index} className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{stat.number}</div>
                    <div className="text-sm text-gray-600">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default TelemedicinePlatform;