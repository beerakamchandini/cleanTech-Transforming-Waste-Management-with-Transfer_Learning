import React from 'react';
import { motion } from 'framer-motion';
import { 
  Microscope, 
  Brain, 
  Users, 
  Award, 
  Target,
  Zap,
  Shield,
  Globe,
  TrendingUp,
  Heart
} from 'lucide-react';

const AboutPage: React.FC = () => {
  const teamMembers = [
    {
      name: 'Dr. Sarah Chen',
      role: 'Chief Medical Officer',
      expertise: 'Hematology & AI Research',
      image: 'https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      name: 'Dr. Michael Rodriguez',
      role: 'Lead AI Researcher',
      expertise: 'Machine Learning & Computer Vision',
      image: 'https://images.pexels.com/photos/5327656/pexels-photo-5327656.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      name: 'Dr. Emily Johnson',
      role: 'Clinical Director',
      expertise: 'Laboratory Medicine & Diagnostics',
      image: 'https://images.pexels.com/photos/5327921/pexels-photo-5327921.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      name: 'Dr. David Kim',
      role: 'Technology Director',
      expertise: 'Healthcare Technology & Innovation',
      image: 'https://images.pexels.com/photos/5327580/pexels-photo-5327580.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  const achievements = [
    {
      icon: Award,
      title: 'FDA Breakthrough Device',
      description: 'Designated as breakthrough technology for blood cell analysis'
    },
    {
      icon: TrendingUp,
      title: '99.2% Accuracy',
      description: 'Industry-leading classification accuracy across all cell types'
    },
    {
      icon: Users,
      title: '500+ Hospitals',
      description: 'Deployed in leading healthcare institutions worldwide'
    },
    {
      icon: Globe,
      title: 'Global Impact',
      description: 'Serving patients across 50+ countries'
    }
  ];

  const researchHighlights = [
    {
      title: 'Transfer Learning Innovation',
      description: 'Pioneered the use of transfer learning for medical image classification, reducing training time by 80% while improving accuracy.',
      impact: '80% faster training'
    },
    {
      title: 'Multi-Modal Analysis',
      description: 'Developed advanced algorithms that combine morphological and spectral analysis for comprehensive cell characterization.',
      impact: '15% accuracy improvement'
    },
    {
      title: 'Real-Time Processing',
      description: 'Optimized neural networks for real-time analysis, enabling instant diagnostic feedback in clinical settings.',
      impact: '<50ms processing time'
    }
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            About HematoVision
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Pioneering the future of healthcare diagnostics through advanced AI and transfer learning technology. 
            Our mission is to make accurate blood cell classification accessible to healthcare providers worldwide.
          </p>
        </motion.div>

        {/* Mission & Vision */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20"
        >
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-8 border border-blue-100">
            <div className="flex items-center mb-6">
              <div className="bg-blue-600 p-3 rounded-xl mr-4">
                <Target className="h-8 w-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Our Mission</h2>
            </div>
            <p className="text-gray-700 leading-relaxed">
              To revolutionize healthcare diagnostics by providing accurate, efficient, and accessible 
              blood cell classification technology. We believe that advanced AI should enhance human 
              expertise, not replace it, creating a collaborative environment where technology and 
              medical professionals work together to improve patient outcomes.
            </p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-violet-50 rounded-2xl p-8 border border-purple-100">
            <div className="flex items-center mb-6">
              <div className="bg-purple-600 p-3 rounded-xl mr-4">
                <Heart className="h-8 w-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Our Vision</h2>
            </div>
            <p className="text-gray-700 leading-relaxed">
              A world where every patient, regardless of location or resources, has access to 
              world-class diagnostic capabilities. Through our AI-powered platform, we envision 
              democratizing healthcare by bringing expert-level blood cell analysis to every 
              corner of the globe, ultimately saving lives and improving health outcomes.
            </p>
          </div>
        </motion.div>

        {/* Technology Overview */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Advanced Technology Stack
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Built on cutting-edge AI research and validated through extensive clinical trials
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Brain className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Transfer Learning</h3>
                <p className="text-gray-600">
                  Leveraging pre-trained convolutional neural networks to achieve superior 
                  accuracy with reduced training requirements.
                </p>
              </div>

              <div className="text-center">
                <div className="bg-gradient-to-r from-green-600 to-emerald-600 w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Real-Time Processing</h3>
                <p className="text-gray-600">
                  Optimized algorithms deliver instant results, enabling immediate clinical 
                  decision-making and improved patient care.
                </p>
              </div>

              <div className="text-center">
                <div className="bg-gradient-to-r from-purple-600 to-violet-600 w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Clinical Grade</h3>
                <p className="text-gray-600">
                  FDA-compliant system designed to meet the highest standards of medical 
                  device safety and efficacy.
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Research Highlights */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Research & Innovation
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Breakthrough research that's advancing the field of medical AI
            </p>
          </div>

          <div className="space-y-8">
            {researchHighlights.map((research, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100"
              >
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-center">
                  <div className="lg:col-span-3">
                    <h3 className="text-xl font-semibold text-gray-900 mb-3">{research.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{research.description}</p>
                  </div>
                  <div className="text-center lg:text-right">
                    <div className="inline-block bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold py-3 px-6 rounded-xl">
                      {research.impact}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Team Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Our Expert Team
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Leading researchers and clinicians dedicated to advancing healthcare through AI
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 text-center hover:shadow-xl transition-all duration-300"
              >
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-lg font-semibold text-gray-900 mb-1">{member.name}</h3>
                <p className="text-blue-600 font-medium mb-2">{member.role}</p>
                <p className="text-sm text-gray-600">{member.expertise}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Achievements */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-gray-50 to-blue-50 rounded-2xl p-8 border border-gray-100"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Recognition & Achievements
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Industry recognition for our contributions to healthcare innovation
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="bg-white w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <achievement.icon className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{achievement.title}</h3>
                <p className="text-gray-600">{achievement.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AboutPage;