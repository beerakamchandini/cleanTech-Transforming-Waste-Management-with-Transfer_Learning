import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  GraduationCap, 
  BookOpen, 
  Users, 
  Award, 
  Play,
  CheckCircle,
  Star,
  Clock,
  Target,
  Brain,
  Microscope,
  FileText
} from 'lucide-react';

const EducationalTools: React.FC = () => {
  const [activeModule, setActiveModule] = useState(0);

  const learningModules = [
    {
      id: 1,
      title: 'Blood Cell Fundamentals',
      description: 'Learn the basics of blood cell types and their characteristics',
      duration: '45 min',
      difficulty: 'Beginner',
      lessons: 8,
      completed: true
    },
    {
      id: 2,
      title: 'Microscopy Techniques',
      description: 'Master the art of blood smear preparation and examination',
      duration: '60 min',
      difficulty: 'Intermediate',
      lessons: 12,
      completed: false
    },
    {
      id: 3,
      title: 'AI-Assisted Classification',
      description: 'Understanding how AI enhances blood cell identification',
      duration: '30 min',
      difficulty: 'Advanced',
      lessons: 6,
      completed: false
    },
    {
      id: 4,
      title: 'Clinical Applications',
      description: 'Real-world case studies and diagnostic scenarios',
      duration: '90 min',
      difficulty: 'Expert',
      lessons: 15,
      completed: false
    }
  ];

  const interactiveFeatures = [
    {
      icon: Microscope,
      title: 'Virtual Microscopy',
      description: 'Explore high-resolution blood cell images with interactive annotations'
    },
    {
      icon: Brain,
      title: 'AI Training Simulator',
      description: 'Practice with our AI system to improve classification accuracy'
    },
    {
      icon: Target,
      title: 'Skill Assessment',
      description: 'Test your knowledge with adaptive quizzes and practical exercises'
    },
    {
      icon: Users,
      title: 'Collaborative Learning',
      description: 'Join study groups and learn from peers and experts'
    }
  ];

  const studentProgress = {
    overallProgress: 65,
    modulesCompleted: 1,
    totalModules: 4,
    skillLevel: 'Intermediate',
    certificationsEarned: 2
  };

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Educational Tools & Training
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Interactive learning platform for medical students and laboratory technicians. 
            Master blood cell classification with AI-powered educational tools.
          </p>
        </motion.div>

        {/* Student Dashboard */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="bg-white rounded-2xl shadow-lg p-8 mb-12 border border-gray-100"
        >
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Progress Overview */}
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
                <GraduationCap className="h-6 w-6 mr-3 text-purple-600" />
                Learning Progress
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-purple-50 p-6 rounded-xl border border-purple-100">
                  <div className="text-3xl font-bold text-purple-600 mb-2">
                    {studentProgress.overallProgress}%
                  </div>
                  <p className="text-purple-700 font-medium">Overall Progress</p>
                </div>
                <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
                  <div className="text-3xl font-bold text-blue-600 mb-2">
                    {studentProgress.modulesCompleted}/{studentProgress.totalModules}
                  </div>
                  <p className="text-blue-700 font-medium">Modules Completed</p>
                </div>
                <div className="bg-green-50 p-6 rounded-xl border border-green-100">
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    {studentProgress.certificationsEarned}
                  </div>
                  <p className="text-green-700 font-medium">Certifications</p>
                </div>
              </div>

              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Current Skill Level</h3>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-600">Progress to Advanced</span>
                  <span className="font-semibold text-gray-900">75%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div className="bg-gradient-to-r from-purple-500 to-violet-500 h-3 rounded-full" style={{ width: '75%' }}></div>
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  Complete 2 more modules to reach Advanced level
                </p>
              </div>
            </div>

            {/* Quick Actions */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <button className="w-full bg-gradient-to-r from-purple-600 to-violet-600 text-white font-semibold py-3 px-4 rounded-xl hover:from-purple-700 hover:to-violet-700 transition-all duration-300 flex items-center justify-center">
                  <Play className="h-5 w-5 mr-2" />
                  Continue Learning
                </button>
                <button className="w-full border border-gray-300 text-gray-700 font-semibold py-3 px-4 rounded-xl hover:bg-gray-50 transition-colors flex items-center justify-center">
                  <Target className="h-5 w-5 mr-2" />
                  Take Assessment
                </button>
                <button className="w-full border border-gray-300 text-gray-700 font-semibold py-3 px-4 rounded-xl hover:bg-gray-50 transition-colors flex items-center justify-center">
                  <Users className="h-5 w-5 mr-2" />
                  Join Study Group
                </button>
              </div>

              <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-xl">
                <div className="flex items-center space-x-3">
                  <Award className="h-6 w-6 text-yellow-600" />
                  <div>
                    <p className="font-medium text-yellow-900">Achievement Unlocked!</p>
                    <p className="text-sm text-yellow-700">Blood Cell Expert Badge</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Learning Modules */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Interactive Learning Modules
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive curriculum designed by medical experts and enhanced with AI technology
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {learningModules.map((module, index) => (
              <motion.div
                key={module.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`bg-white rounded-2xl p-6 shadow-lg border transition-all duration-300 hover:shadow-xl cursor-pointer ${
                  activeModule === index ? 'border-purple-300 ring-2 ring-purple-100' : 'border-gray-100'
                }`}
                onClick={() => setActiveModule(index)}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${module.completed ? 'bg-green-100' : 'bg-purple-100'}`}>
                      {module.completed ? (
                        <CheckCircle className="h-6 w-6 text-green-600" />
                      ) : (
                        <BookOpen className="h-6 w-6 text-purple-600" />
                      )}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{module.title}</h3>
                      <p className="text-sm text-gray-600">{module.description}</p>
                    </div>
                  </div>
                  {module.completed && (
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="text-center">
                    <Clock className="h-5 w-5 text-gray-400 mx-auto mb-1" />
                    <p className="text-sm text-gray-600">{module.duration}</p>
                  </div>
                  <div className="text-center">
                    <Target className="h-5 w-5 text-gray-400 mx-auto mb-1" />
                    <p className="text-sm text-gray-600">{module.difficulty}</p>
                  </div>
                  <div className="text-center">
                    <FileText className="h-5 w-5 text-gray-400 mx-auto mb-1" />
                    <p className="text-sm text-gray-600">{module.lessons} lessons</p>
                  </div>
                </div>

                <button className={`w-full font-semibold py-3 px-4 rounded-xl transition-all duration-300 ${
                  module.completed
                    ? 'bg-green-100 text-green-700 hover:bg-green-200'
                    : 'bg-purple-600 text-white hover:bg-purple-700'
                }`}>
                  {module.completed ? 'Review Module' : 'Start Learning'}
                </button>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Interactive Features */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Interactive Learning Features
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Hands-on tools and simulations for immersive medical education
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {interactiveFeatures.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 group"
              >
                <div className="bg-gradient-to-r from-purple-500 to-violet-500 w-12 h-12 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <feature.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Virtual Lab Demo */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-purple-50 to-violet-50 rounded-2xl p-8 border border-purple-100"
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Virtual Laboratory Experience
              </h2>
              <p className="text-lg text-gray-600 mb-8">
                Practice blood cell identification in our state-of-the-art virtual laboratory. 
                Get instant feedback from our AI system and track your improvement over time.
              </p>
              
              <div className="space-y-4 mb-8">
                {[
                  'High-resolution microscopy simulations',
                  'Real-time AI feedback and corrections',
                  'Progressive difficulty levels',
                  'Comprehensive performance analytics'
                ].map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-purple-600" />
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>

              <button className="bg-gradient-to-r from-purple-600 to-violet-600 text-white font-semibold py-4 px-8 rounded-xl hover:from-purple-700 hover:to-violet-700 transition-all duration-300 transform hover:scale-105">
                Launch Virtual Lab
              </button>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-lg">
              <div className="bg-gray-900 rounded-lg p-6 aspect-video flex items-center justify-center mb-6">
                <div className="text-center text-white">
                  <Microscope className="h-16 w-16 mx-auto mb-4 opacity-50" />
                  <p className="text-lg font-medium">Virtual Microscope</p>
                  <p className="text-gray-400">Interactive blood cell examination</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-purple-50 rounded-lg">
                  <div className="text-xl font-bold text-purple-600">98%</div>
                  <div className="text-sm text-gray-600">Accuracy Rate</div>
                </div>
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-xl font-bold text-blue-600">247</div>
                  <div className="text-sm text-gray-600">Cells Analyzed</div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default EducationalTools;